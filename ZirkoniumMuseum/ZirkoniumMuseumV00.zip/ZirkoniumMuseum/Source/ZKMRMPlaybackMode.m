//
//  ZKMRMPlaybackMode.m
//  ZirkoniumMuseum
//
//  Created by C. Ramakrishnan on 03.09.09.
//  Copyright 2009 Illposed Software. All rights reserved.
//

#import "ZKMRMPlaybackMode.h"


@implementation ZKMRMPlaybackMode

- (void)activate
{
	// Subclass responsibility
}

@end

@implementation ZKMRMPlaybackModeUser

@end

@implementation ZKMRMPlaybackModeAutomatic

@end