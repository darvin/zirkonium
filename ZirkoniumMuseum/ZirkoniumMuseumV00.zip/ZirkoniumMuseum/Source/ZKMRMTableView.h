//
//  ZKMRMTableView.h
//  ZirkoniumMuseum
//
//  Created by C. Ramakrishnan on 11.09.09.
//  Copyright 2009 Illposed Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface ZKMRMTableView : NSTableView {

}

@end

@interface ZKMRMTableViewTextFieldCell : NSTextFieldCell {

}

@end
