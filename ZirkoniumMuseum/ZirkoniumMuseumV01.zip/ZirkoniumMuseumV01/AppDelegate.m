//
//  AppDelegate.m
//  ZirkoniumMuseum
//
//  Created by Jens on 20.07.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"


@implementation AppDelegate

-(IBAction)actionToggleFullscreen:(id)sender
{
	[system toggleFullScreen]; 
}

@end
