//
//  MuseumView.h
//  ZirkoniumMuseum
//
//  Created by Jens on 02.08.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "ZKMRNSpatializerView.h"

@interface MuseumView : ZKMRNSpatializerView {

}

@end
