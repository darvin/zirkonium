//
//  ZKMRMBorderlessWindow.h
//  ZirkoniumMuseum
//
//  Created by C. Ramakrishnan on 06.08.09.
//  Copyright 2009 Illposed Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface ZKMRMBorderlessWindow : NSWindow {

}

@end
