//
//  ItemView.h
//  ZirkoniumMuseum
//
//  Created by Jens on 19.07.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ItemView : NSView {
}
-(void)setSelected:(BOOL)flag;

@end
