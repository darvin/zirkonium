//
//  ZKMRMKeyDownView.h
//  ZirkoniumMuseum
//
//  Created by C. Ramakrishnan on 29.09.09.
//  Copyright 2009 Illposed Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface ZKMRMKeyDownView : NSView {

}

@end
